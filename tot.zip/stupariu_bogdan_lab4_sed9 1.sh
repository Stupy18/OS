#!/bin/bash
if [ ! -f "$1"] || [ ! -r "$1" ]; then
	echo "Error:kein textfile"
	exit 1
fi
sed -E 's/^(\w+)(\s+\w+)?(\s+\w+)?(\s+\w+)?/\1\3/' "$1"

