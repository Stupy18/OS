#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

#define BUF_SIZE 256
#define FIFO_4 "fifo4"

int main(void) {
    char buffer[BUF_SIZE];
    int fd4, n;

    // Open the FIFO for reading
    fd4 = open(FIFO_4, O_RDONLY);

    // Read from fd3 and write to standard output using printf
    while ((n = read(fd4, buffer, sizeof(buffer))) > 0) {
        buffer[n] = '\0'; // Null-terminate the buffer

        // Print the contents of the buffer to standard output
        printf("%s", buffer);
    }


    // Close the FIFO
    close(fd4);

    return 0;
}
