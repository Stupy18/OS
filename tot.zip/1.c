#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>

#define BUF_SIZE 256
#define FIFO_2 "fifo2"
#define FIFO_3 "fifo3"
#define FIFO_4 "fifo4"

int main(void) {
    char buffer[BUF_SIZE];
    int fd2, fd3, fd4;

    // Open the FIFOs for writing
    fd2 = open(FIFO_2, O_WRONLY);
    fd3 = open(FIFO_3, O_WRONLY);
    fd4 = open(FIFO_4, O_WRONLY);

    // Read from standard input and send lines to the respective FIFOs
    while (fgets(buffer, sizeof(buffer), stdin) != NULL) {
        if (isalpha(buffer[0])) {
            write(fd2, buffer, strlen(buffer));
        } else if (isdigit(buffer[0])) {
            write(fd3, buffer, strlen(buffer));
        } else {
            write(fd4, buffer, strlen(buffer));
        }
    }

    // Close the FIFOs
    close(fd2);
    close(fd3);
    close(fd4);

    return 0;
}
