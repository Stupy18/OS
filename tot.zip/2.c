#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

#define BUF_SIZE 256
#define FIFO_2 "fifo2"

int main(void) {
    char buffer[BUF_SIZE];
    int fd2, n;

    // Open the FIFO for reading
    fd2 = open(FIFO_2, O_RDONLY);

    // Read from fd3 and write to standard output using printf
    while ((n = read(fd2, buffer, sizeof(buffer))) > 0) {
        buffer[n] = '\0'; // Null-terminate the buffer

        // Print the contents of the buffer to standard output
        printf("%s", buffer);
    }

    // Close the FIFO
    close(fd2);

    return 0;
}
