#!/bin/bash
rm -rf Worterbuch
if [ ! -f "$1" ]
then
	echo:"Error:Kein Textfile"
	exit 1
fi

input_file=$1
mkdir Worterbuch

for letter in {A..Z} 
do
	touch Worterbuch/$letter
	grep -io "\b$letter[[:alpha:]]*\b" $input_file | sort > Worterbuch/$letter
done
