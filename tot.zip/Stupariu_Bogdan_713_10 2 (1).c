#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    int pipe1[2];  // Pipe 1: Process 1 -> Process 2
    int pipe2[2];  // Pipe 2: Process 1 -> Process 3
    int pipe3[2];  // Pipe 3: Process 2 -> Process 4

    if (pipe(pipe1) == -1 || pipe(pipe2) == -1 || pipe(pipe3) == -1) {
        perror("Pipe creation failed");
        exit(EXIT_FAILURE);
    }

    pid_t pid1, pid2, pid3, pid4;

    pid1 = fork();

    if (pid1 == -1) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid1 == 0) {
        // Process 1
        close(pipe1[0]);  // Close read end of pipe 1
        close(pipe2[0]);  // Close read end of pipe 2
        close(pipe3[0]);  // Close read end of pipe 3
        close(pipe3[1]);  // Close write end of pipe 3

        printf("Process 1: Enter input: ");
        char input[100];
        fgets(input, sizeof(input), stdin);

        int hasLetters = 0;
        for (int i = 0; input[i] != '\0'; i++) {
            if (!isdigit(input[i]) && isalpha(input[i])) {
                hasLetters = 1;
                break;
            }
        }

        if (hasLetters) {
            write(pipe1[1], input, sizeof(input));
        } else {
            write(pipe2[1], input, sizeof(input));
        }

        close(pipe1[1]);  // Close write end of pipe 1
        exit(EXIT_SUCCESS);
    }

    pid2 = fork();

    if (pid2 == -1) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid2 == 0) {
        // Process 2
        close(pipe1[1]);  // Close write end of pipe 1
        close(pipe2[0]);  // Close read end of pipe 2
        close(pipe3[0]);  // Close read end of pipe 3

        char input[100];
        read(pipe1[0], input, sizeof(input));
        close(pipe1[0]);  // Close read end of pipe 1

        // Convert numbers to underscores
        for (int i = 0; input[i] != '\0'; i++) {
            if (isdigit(input[i])) {
                input[i] = '_';
            }
        }

        write(pipe3[1], input, sizeof(input));
        close(pipe3[1]);  // Close write end of pipe 3
        exit(EXIT_SUCCESS);
    }

    pid3 = fork();

    if (pid3 == -1) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid3 == 0) {
        // Process 3
        close(pipe1[0]);  // Close read end of pipe 1
        close(pipe1[1]);  // Close write end of pipe 1
        close(pipe2[1]);  // Close write end of pipe 2
        close(pipe3[0]);  // Close read end of pipe 3

        char input[100];
        read(pipe2[0], input, sizeof(input));
        close(pipe2[0]);  // Close read end of pipe 2

        printf("Process 3: Received input: %s\n", input);
        exit(EXIT_SUCCESS);
    }

    pid4 = fork();

    if (pid4 == -1) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid4 == 0) {
        // Process 4
        close(pipe1[0]);  // Close read end of pipe 1
        close(pipe1[1]);  // Close write end of pipe 1
        close(pipe2[1]);  // Close write end of pipe 2
        close(pipe3[1]);  // Close write end of pipe 3

        char input[100];
        read(pipe3[0], input, sizeof(input));
        close(pipe3[0]);  // Close read end of pipe 3

        printf("Process 4: Received input: %s\n", input);
        exit(EXIT_SUCCESS);
    }

    // Parent process
    close(pipe1[0]);  // Close read end of pipe 1
    close(pipe1[1]);  // Close write end of pipe 1
    close(pipe2[0]);  // Close read end of pipe 2
    close(pipe2[1]);  // Close write end of pipe 2
    close(pipe3[0]);  // Close read end of pipe 3
    close(pipe3[1]);  // Close write end of pipe 3

    // Wait for all child processes to finish
    wait(NULL);
    wait(NULL);
    wait(NULL);
    wait(NULL);

    return 0;
}