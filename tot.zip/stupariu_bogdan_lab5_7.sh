#!/bin/bash
if [ ! -f $1 ]; then
	echo"Error:Kein Textfile"
	exit 1
fi
for file in "$@"; do

	awk '{
		if (length($0) > 30) {
			print NR, $1, $NF
		}
	     }' "$file"

done
