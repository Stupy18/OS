#!/bin/bash
if [ ! -d "$1" ]; then
	echo "Error:Kein File"
	exit 1
fi
cd $1
grep -rl "#define" *.c | sort
