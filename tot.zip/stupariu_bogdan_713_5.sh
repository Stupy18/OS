#!/bin/bash
echo "Bitte geben Sie eine Zahl ein:"
read num
if [ $num -lt 2 ]
	then
		echo "not prime"
		exit 0
fi
for ((i=2; i<=$num/2; i++))
do
	if [ $((num%i)) -eq 0 ]
	then
		echo "not prime"
		exit 0
	fi
done
echo "prime"

