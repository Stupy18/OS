#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 1000

int main(int argc, char *argv[]) {
    // Überprüfen, ob die Anzahl der Argumente korrekt ist
    if (argc != 3) {
        printf("Verwendung: %s <Wort> <Dateiname>\n", argv[0]);
        return 1;
    }

    // Das zu löschende Wort und den Dateinamen aus den Argumenten lesen
    char *word_to_delete = argv[1];
    char *filename = argv[2];

    // Die Datei zum Lesen und Schreiben öffnen
    FILE *file = fopen(filename, "r+");
    if (file == NULL) {
        printf("Error: could not open file %s\n", filename);
        return 1;
    }

    // Jede Zeile in der Datei verarbeiten
    char line[MAX_LINE_LENGTH];
    int num_deleted_occurrences = 0;
    while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
        // Nach dem zu löschenden Wort in der aktuellen Zeile suchen
        char *match = strstr(line, word_to_delete);
        while (match != NULL) {
            // Das gefundene Wort durch Leerzeichen ersetzen
            memset(match, ' ', strlen(word_to_delete));
            num_deleted_occurrences++;

            // Nach dem nächsten Treffer suchen
            match = strstr(match + strlen(word_to_delete), word_to_delete);
        }
        // Die modifizierte Zeile in die Datei schreiben
        fseek(file, -strlen(line), SEEK_CUR);
        fputs(line, file);
        fflush(file);
    }

    // Die Datei schließen und die Anzahl der gelöschten Vorkommen ausgeben
    fclose(file);
    printf("Deleted %d occurrences of the word '%s'\n", num_deleted_occurrences, word_to_delete);
    return 0;
}
