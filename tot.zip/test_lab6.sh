#!/bin/bash

dir="Worterbuch"

for file in  "$dir"/*
	do
		if [ -f "$file" ]
			then
				echo "----$file----"
				cat "$file"
				echo ""
		fi
done
