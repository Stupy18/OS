#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int isPerfect(int num) {
    int sum = 0;
    for (int i = 1; i < num; i++) {
        if (num % i == 0) {
            sum += i;
        }
    }
    return (sum == num);
}

void findPerfectNumbers(int start, int end) {
    for (int i = start; i <= end; i++) {
        if (isPerfect(i)) {
            printf("%d is a perfect number.\n", i);
        }
    }
}

int main() {
    int N;
    printf("Enter a number N: ");
    scanf("%d", &N);

    int process_count = 3; // Number of processes to use
    int numbers_per_process = N / process_count;
    int remaining_numbers = N % process_count;
    int start = 1;
    int end;

    for (int i = 0; i < process_count; i++) {
        end = start + numbers_per_process - 1;
        if (i == process_count - 1) {
            end += remaining_numbers;
        }

        if (fork() == 0) {
            // Child process
            findPerfectNumbers(start, end);
            exit(0);
        } else {
            // Parent process
            start = end + 1;
        }
    }

    for (int i = 0; i < process_count; i++) {
        wait(NULL);
    }

    return 0;
}
